function out = run_one_MC_spice(k, metaKernelPath)
    spice_init(metaKernelPath);

    % --- SPICE calls are now safe on this worker ---
    % et = cspice_str2et('2026-01-26T00:00:00');
    % state = cspice_spkezr('MOON', et, 'J2000', 'NONE', 'EARTH');

    out = k; % replace with real output

    % HERE you can try to write you main function ...
end
