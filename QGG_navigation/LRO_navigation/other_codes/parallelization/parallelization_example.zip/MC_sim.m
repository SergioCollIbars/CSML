MC = 100;
pool = gcp;

metaKernelPath = '/absolute/path/to/your.tm';  % use absolute path.

futures(MC) = parallel.FevalFuture;
for k = 1:MC
    futures(k) = parfeval(pool, @run_one_MC_spice, 1, k, metaKernelPath);
end

results = cell(MC,1);
for n = 1:MC
    [idx, out] = fetchNext(futures);
    results{idx} = out;
    fprintf("Done %d/%d (run %d)\n", n, MC, idx);
end
