%%                  EXAMPLE CODE
% Author: Sergio Coll-Ibars
% Date: 11/12/2025
% Description: Show an example on how to use the 'sendOpenFiguresByEmail.m'
% function works.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear; clc;

%% Step 1: Copy & paste the following setUp code 
% email settings
myEmail    = 'youremail@gmail.com';                                         % your email go here
myPassword = 'yourPassword';                                                % if using gmail, setup password in: 2-step-verification account settings
email = 1;                                                                  % send plots by email 1 = yes / 0 = no

setpref('Internet','E_mail',myEmail);
setpref('Internet','SMTP_Server','smtp.gmail.com');
setpref('Internet','SMTP_Username',myEmail);                                
setpref('Internet','SMTP_Password',myPassword);                             
props = java.lang.System.getProperties;
props.setProperty('mail.smtp.auth','true');
props.setProperty('mail.smtp.starttls.enable','true'); % For TLS
props.setProperty('mail.smtp.port','587'); % Common TLS port

% Start diary logging
diaryFile = fullfile(tempdir, 'console_log.txt');
if isfile(diaryFile)
    delete(diaryFile);
end
diary(diaryFile);
diary on;

%% Step 2: launch your code (example)
n = 1:10;
y = 3.*n;

figure()
plot(n, y, 'LineWidth', 2);

disp('This message is displayed in the console');

%% Step 3: Copy & paste the following function
if(email)
    % load console output 
    consoleText = fileread(diaryFile);
    
    sendOpenFiguresByEmail(...
        myEmail, ...
        'Auto Report - MATLAB Figures', consoleText);
end
delete(diaryFile);  % clean up immediately
